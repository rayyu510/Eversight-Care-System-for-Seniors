export interface SecurityPolicy {
  id: string;
  name: string;
  isActive: boolean;
}
