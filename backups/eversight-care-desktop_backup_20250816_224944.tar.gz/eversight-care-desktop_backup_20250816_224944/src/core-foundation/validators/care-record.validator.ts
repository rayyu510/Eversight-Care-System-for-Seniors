export const careRecordValidator = (): any => ({ isValid: true, errors: [] });
export default careRecordValidator;
