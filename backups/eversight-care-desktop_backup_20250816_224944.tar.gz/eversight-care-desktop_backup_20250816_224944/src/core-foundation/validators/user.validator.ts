export const userValidator = (): any => ({ isValid: true, errors: [] });
export default userValidator;
