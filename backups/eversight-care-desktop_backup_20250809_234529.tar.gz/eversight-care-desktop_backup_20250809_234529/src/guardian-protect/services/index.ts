// src/guardian-protect/services/index.ts
// Simple exports without complex dependencies

// Temporary placeholder exports to prevent "can't find module" errors
export class FallDetectionService {
    constructor() { }
    async shutdown() { }
}

export class VideoStreamService {
    constructor() { }
    async shutdown() { }
}

export class EmergencyResponseService {
    constructor() { }
    async shutdown() { }
}