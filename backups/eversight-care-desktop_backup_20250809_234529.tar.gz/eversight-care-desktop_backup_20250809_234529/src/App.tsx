// File: src/App.tsx - Minimal test
import React from 'react';

function App() {
    return (
        <div>
            <h1>Hello Guardian Protect!</h1>
            <p>React is working!</p>
        </div>
    );
}

export default App;