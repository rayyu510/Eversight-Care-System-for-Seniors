export const authMiddleware = (): void => { };
export default authMiddleware;
