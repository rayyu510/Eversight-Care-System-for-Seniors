export const loggingMiddleware = (): void => { };
export default loggingMiddleware;
