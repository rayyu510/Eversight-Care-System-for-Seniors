export const residentValidator = (): any => ({ isValid: true, errors: [] });
export default residentValidator;
