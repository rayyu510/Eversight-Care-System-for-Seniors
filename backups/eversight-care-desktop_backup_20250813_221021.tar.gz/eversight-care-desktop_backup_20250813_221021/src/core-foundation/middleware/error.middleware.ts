export const errorMiddleware = (): void => { };
export default errorMiddleware;
