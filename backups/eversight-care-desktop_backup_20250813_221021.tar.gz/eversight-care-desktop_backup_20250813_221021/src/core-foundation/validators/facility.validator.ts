export const facilityValidator = (): any => ({ isValid: true, errors: [] });
export default facilityValidator;
